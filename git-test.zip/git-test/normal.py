import matplotlib.pyplot as plt
import numpy as np
x = np.random.normal(0, 10,102)
# y = np.random.normal(0, 10,102)


count, bins, ignored = plt.hist(x, 50, density=True)
# plt.plot(bins, 1/(10 * np.sqrt(2 * np.pi)) * np.exp( - (bins - 0)**2 / (2 * 10**2) ),linewidth=2, color='r')
plt.show()
